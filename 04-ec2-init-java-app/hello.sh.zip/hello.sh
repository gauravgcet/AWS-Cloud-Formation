#!/bin/bash -xe
java -jar /var/tmp/hello.jar &